package fr.arsenelapostolet.efrei.monopoly;

public enum OrderKind {
    BUY, PAY_PRISON, IDLE, BUILD
}