package fr.arsenelapostolet.efrei.monopoly;

public interface GameServer {

    void start(int numberOfPlayers, int port, Dices dices);

}
