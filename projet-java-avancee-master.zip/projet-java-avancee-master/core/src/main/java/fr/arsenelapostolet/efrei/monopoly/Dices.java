package fr.arsenelapostolet.efrei.monopoly;

public interface Dices {

    int throwTwoSixSidedDices();

}

